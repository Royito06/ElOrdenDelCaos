#ifndef CAPTURAS&IMPRESIONES_H_INCLUDED
#define CAPTURAS&IMPRESIONES_H_INCLUDED

void GenerarArreglo(int arreglo[],int n);
void GenerarArregloRand(int arreglo[],int n);
void ImprimirHistograma(int arreglo[],int n);
void ImprimirArreglos(int arreglo[], int n);



#endif // CAPTURAS&IMPRESIONES_H_INCLUDED
