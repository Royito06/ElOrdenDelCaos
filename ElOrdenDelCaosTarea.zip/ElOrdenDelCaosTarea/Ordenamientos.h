#ifndef ORDENAMIENTOS_H_INCLUDED
#define ORDENAMIENTOS_H_INCLUDED

void bubble(int data[],int num);

void BubbleBidirecccional(int data[], int num);

void seleccion(int data[], int num);

void insercion(int data[], int num);

void ShellSort(int arreglo[], int n);

void QuickSort(int arreglo[], int primero, int ultimo, int n);
int Particion(int arreglo[], int primero, int ultimo, int n);

void MergeSort(int arreglo[], int n);



#endif // ORDENAMIENTOS_H_INCLUDED
