#ifndef MOVERCURSOR_H_INCLUDED
#define MOVERCURSOR_H_INCLUDED

void MoverCursor(short x, short y);

#endif // MOVERCURSOR_H_INCLUDED
