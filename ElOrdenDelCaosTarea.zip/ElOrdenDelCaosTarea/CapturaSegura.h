#ifndef CAPTURASEGURA_H_INCLUDED
#define CAPTURASEGURA_H_INCLUDED

template <typename Tipo>
bool capturaSegura(Tipo &n);

#endif // CAPTURASEGURA_H_INCLUDED
