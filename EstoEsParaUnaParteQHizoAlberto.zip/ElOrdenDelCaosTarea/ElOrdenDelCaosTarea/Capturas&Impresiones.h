#ifndef CAPTURAS&IMPRESIONES_H_INCLUDED
#define CAPTURAS&IMPRESIONES_H_INCLUDED

//*********************************************************************************************************************************

/**
 * La función "GenerarArreglo" solicita al usuario ingresar un número específico
 * de elementos en un arreglo.
 * 
 * @param data Arreglo de enteros donde se almacenarán los elementos ingresados.
 * @param num  Número de elementos que el usuario ingresará en el arreglo `data[]`.
 */
void GenerarArreglo(int arreglo[],int n);

//*********************************************************************************************************************************

/**
 * Genera un arreglo de enteros aleatorios entre 1 y 20.
 * 
 * @param arreglo Arreglo de enteros que almacenará los valores generados aleatoriamente.
 * @param n       Tamaño del arreglo a generar, determina la cantidad de elementos aleatorios.
 */
void GenerarArregloRand(int arreglo[],int n);

//*********************************************************************************************************************************

/**
 * La función ImprimirHistograma muestra una representación gráfica de un arreglo
 * con una altura específica y limpia la pantalla después de un retraso.
 * 
 * @param arreglo Arreglo de enteros que contiene los valores a visualizar en el histograma.
 * @param n       Tamaño del arreglo (número de elementos a representar en el histograma).
 */
void ImprimirHistograma(int arreglo[],int n);

//*********************************************************************************************************************************

/**
 * La función "ImprimirArreglos" muestra los elementos de un arreglo de enteros.
 * 
 * @param arreglo Arreglo de enteros que contiene los valores a imprimir.
 * @param n       Tamaño del arreglo (número de elementos a mostrar).
 */
void ImprimirArreglos(int arreglo[], int n);

//*********************************************************************************************************************************


#endif // CAPTURAS&IMPRESIONES_H_INCLUDED
