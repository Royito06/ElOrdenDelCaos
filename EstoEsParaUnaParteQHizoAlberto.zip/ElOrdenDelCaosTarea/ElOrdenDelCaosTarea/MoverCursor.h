#ifndef MOVERCURSOR_H_INCLUDED
#define MOVERCURSOR_H_INCLUDED

/**
 * La función `MoverCursor` posiciona el cursor en una ubicación específica 
 * de la pantalla de consola en C++.
 * 
 * @param x Posición horizontal donde se desea ubicar el cursor en la pantalla de consola.
 * @param y Posición vertical donde se desea ubicar el cursor en la pantalla de consola.
 */
void MoverCursor(short x, short y);

#endif // MOVERCURSOR_H_INCLUDED
