#include "VariablesGlobales.h"

extern int x=4, y=4;

